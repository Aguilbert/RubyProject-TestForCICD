//= require jquery
//= require jquery_ujs
//= require jquery.remotipart
//= require turbolinks
//= require jquery.infinitescroll
//= require_tree .

Turbolinks.enableProgressBar();