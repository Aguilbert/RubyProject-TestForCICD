require 'test_helper'

class PasswordResetsControllerTest < ActionController::TestCase

end
