require 'test_helper'

class SongsHelperTest < ActionView::TestCase
end
