require 'test_helper'

class LikeshipsHelperTest < ActionView::TestCase
end
